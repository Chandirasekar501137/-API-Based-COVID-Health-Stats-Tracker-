import React from "react";
import styles from "./CountryResult.module.css";

export default function NotFound({ query }) {
  return (
    <section className={styles.section}>
      <div className={styles.sectionLabel}>Country Report</div>
      <div className={styles.error}>
        <strong>Country not found: "{query}"</strong>
        <br />
        <span style={{ fontSize: "0.82rem", color: "var(--muted)" }}>
          Try: USA, India, Brazil, France, Germany, Japan, UK, Russia, Italy, China,
          South Korea, Spain, Australia, Mexico, Iran, South Africa, Indonesia,
          Pakistan, Sri Lanka, Bangladesh…
        </span>
      </div>
    </section>
  );
}
