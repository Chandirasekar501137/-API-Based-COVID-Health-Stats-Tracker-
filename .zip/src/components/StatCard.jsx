import React from "react";
import styles from "./StatCard.module.css";

export default function StatCard({ label, value, type }) {
  return (
    <div className={`${styles.card} ${styles[type]}`}>
      <div className={styles.label}>{label}</div>
      <div className={styles.value}>{value}</div>
    </div>
  );
}
