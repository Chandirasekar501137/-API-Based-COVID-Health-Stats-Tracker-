import React from "react";
import StatCard from "./StatCard";
import { GLOBAL, fmt } from "../data/covidData";
import styles from "./GlobalStats.module.css";

const cards = [
  { label: "Total Cases",   key: "cases",     type: "cases"     },
  { label: "Total Deaths",  key: "deaths",    type: "deaths"    },
  { label: "Recovered",     key: "recovered", type: "recovered" },
  { label: "Active Cases",  key: "active",    type: "active"    },
  { label: "Critical",      key: "critical",  type: "critical"  },
  { label: "Tests Done",    key: "tests",     type: "tests"     },
];

export default function GlobalStats() {
  return (
    <section className={styles.section}>
      <div className={styles.sectionLabel}>Worldwide Summary</div>
      <div className={styles.grid}>
        {cards.map((c) => (
          <StatCard key={c.key} label={c.label} value={fmt(GLOBAL[c.key])} type={c.type} />
        ))}
      </div>
    </section>
  );
}
