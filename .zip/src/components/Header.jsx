import React from "react";
import styles from "./Header.module.css";

export default function Header() {
  return (
    <header className={styles.header}>
      <div className={styles.logo}>
        <span className={styles.pulse} />
        <div>
          <div className={styles.logoText}>HEALTHTRACK</div>
          <div className={styles.logoSub}>COVID-19 Global Monitor</div>
        </div>
      </div>
      <div className={styles.updated}>WHO Final Report · May 2023</div>
    </header>
  );
}
