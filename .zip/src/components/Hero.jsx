import React from "react";
import styles from "./Hero.module.css";

export default function Hero() {
  return (
    <div className={styles.hero}>
      <h1 className={styles.title}>
        Global <span className={styles.accent}>Health</span> Intelligence
      </h1>
      <p className={styles.desc}>
        Comprehensive COVID-19 statistics for every country — search, compare, and
        identify high-risk regions with instant alerts.
      </p>
      <div className={styles.note}>
        📊 WHO-verified final pandemic totals · 200+ countries
      </div>
    </div>
  );
}
