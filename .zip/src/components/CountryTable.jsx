import React from "react";
import { COUNTRIES, fmt } from "../data/covidData";
import styles from "./CountryTable.module.css";

const sorted = [...COUNTRIES].sort((a, b) => b.cases - a.cases).slice(0, 20);

export default function CountryTable({ onSelect }) {
  return (
    <section className={styles.section}>
      <div className={styles.sectionLabel}>Top Affected Countries</div>
      <div className={styles.tableWrap}>
        <div className={styles.tableHeader}>
          <span className={styles.tableTitle}>Countries by Total Cases</span>
          <span className={styles.tableCount}>Top 20 of 200+ countries</span>
        </div>
        <div className={styles.tableScroll}>
          <table className={styles.table}>
            <thead>
              <tr>
                <th className={styles.thLeft}>Country</th>
                <th>Total Cases</th>
                <th>Deaths</th>
                <th>Recovered</th>
                <th>Active</th>
              </tr>
            </thead>
            <tbody>
              {sorted.map((c, i) => (
                <tr key={c.country} onClick={() => onSelect(c.country)} className={styles.row}>
                  <td className={styles.tdName}>
                    <span className={styles.tableFlag}>{c.flag}</span>
                    {i + 1}. {c.country}
                  </td>
                  <td className={styles.tdCases}>{fmt(c.cases)}</td>
                  <td className={styles.tdDeaths}>{fmt(c.deaths)}</td>
                  <td className={styles.tdRecov}>{fmt(c.recovered)}</td>
                  <td className={styles.tdActive}>{fmt(c.active)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </section>
  );
}
