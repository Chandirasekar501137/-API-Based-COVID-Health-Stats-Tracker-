import React, { useState } from "react";
import styles from "./SearchBar.module.css";

export default function SearchBar({ onSearch, onClear }) {
  const [query, setQuery] = useState("");

  const handleSearch = () => {
    if (query.trim()) onSearch(query.trim());
  };

  const handleClear = () => {
    setQuery("");
    onClear();
  };

  return (
    <div className={styles.bar}>
      <div className={styles.inputWrap}>
        <svg className={styles.icon} width="16" height="16" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
          <circle cx="11" cy="11" r="8" />
          <path d="m21 21-4.35-4.35" />
        </svg>
        <input
          className={styles.input}
          type="text"
          placeholder="Search country — e.g. India, USA, Brazil, Germany…"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && handleSearch()}
        />
      </div>
      <button className={styles.btn} onClick={handleSearch}>Search</button>
      <button className={`${styles.btn} ${styles.btnOutline}`} onClick={handleClear}>Global View</button>
    </div>
  );
}
