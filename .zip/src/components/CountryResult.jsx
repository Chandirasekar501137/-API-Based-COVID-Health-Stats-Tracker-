import React from "react";
import StatCard from "./StatCard";
import { getRisk, fmt, pct } from "../data/covidData";
import styles from "./CountryResult.module.css";

function AlertBox({ level, country }) {
  const map = {
    high: {
      cls: styles.alertDanger,
      icon: "🚨",
      title: `High Risk Alert — ${country}:`,
      msg: "This country recorded critically high case and death rates per million population. Health authorities placed it in the highest monitoring tier during the pandemic.",
    },
    medium: {
      cls: styles.alertWarn,
      icon: "⚠️",
      title: `Moderate Risk — ${country}:`,
      msg: "Elevated infection and mortality rates were recorded. Public health guidelines and travel advisories were in effect for extended periods.",
    },
    low: {
      cls: styles.alertSafe,
      icon: "✅",
      title: `Lower Risk — ${country}:`,
      msg: "Relatively lower transmission and mortality rates compared to global averages. Standard precautions were recommended.",
    },
  };
  const { cls, icon, title, msg } = map[level];
  return (
    <div className={`${styles.alert} ${cls}`}>
      <span className={styles.alertIcon}>{icon}</span>
      <div><strong>{title}</strong> {msg}</div>
    </div>
  );
}

function RiskBadge({ level }) {
  const map = {
    high:   { cls: styles.riskHigh,   label: "🔴 HIGH RISK" },
    medium: { cls: styles.riskMedium, label: "🟡 MODERATE" },
    low:    { cls: styles.riskLow,    label: "🟢 LOW RISK" },
  };
  const { cls, label } = map[level];
  return <span className={`${styles.badge} ${cls}`}>{label}</span>;
}

const statRows = [
  { label: "Total Cases",    key: "cases",     type: "cases"     },
  { label: "Total Deaths",   key: "deaths",    type: "deaths"    },
  { label: "Recovered",      key: "recovered", type: "recovered" },
  { label: "Active Cases",   key: "active",    type: "active"    },
  { label: "Critical",       key: "critical",  type: "critical"  },
  { label: "Cases / Million",key: "casesPerM", type: "cases"     },
  { label: "Deaths / Million",key:"deathsPerM",type: "deaths"    },
  { label: "Tests / Million",key: "testsPerM", type: "tests"     },
];

export default function CountryResult({ country }) {
  if (!country) return null;
  const risk = getRisk(country);

  return (
    <section className={styles.section}>
      <div className={styles.sectionLabel}>Country Report</div>
      <AlertBox level={risk} country={country.country} />
      <div className={styles.header}>
        <span className={styles.flag}>{country.flag}</span>
        <div>
          <div className={styles.name}>
            {country.country}
            <RiskBadge level={risk} />
          </div>
          <div className={styles.sub}>
            {country.continent} · Population: {fmt(country.population)}
          </div>
          <div className={styles.sub}>
            Death Rate:{" "}
            <strong style={{ color: "var(--danger)" }}>
              {pct(country.deaths, country.cases)}
            </strong>
            {" "}· Recovery Rate:{" "}
            <strong style={{ color: "var(--safe)" }}>
              {pct(country.recovered, country.cases)}
            </strong>
          </div>
        </div>
      </div>
      <div className={styles.grid}>
        {statRows.map((r) => (
          <StatCard key={r.key} label={r.label} value={fmt(country[r.key])} type={r.type} />
        ))}
      </div>
    </section>
  );
}
