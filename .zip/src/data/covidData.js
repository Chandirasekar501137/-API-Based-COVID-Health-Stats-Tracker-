export const GLOBAL = {
  cases: 676609955,
  deaths: 6881955,
  recovered: 651000000,
  active: 3800000,
  critical: 42000,
  tests: 7000000000,
  updated: "May 5, 2023 (WHO Final Report)",
};

export const COUNTRIES = [
  { country: "USA",          flag: "🇺🇸", continent: "North America",  population: 331000000,   cases: 103802702, deaths: 1127152, recovered: 100674000, active: 1000000, critical: 1500,  casesPerM: 313605, deathsPerM: 3405,  testsPerM: 3080000 },
  { country: "India",        flag: "🇮🇳", continent: "Asia",           population: 1380000000,  cases: 44690764,  deaths: 530779,  recovered: 44150000,  active: 9985,    critical: 39,    casesPerM: 32386,  deathsPerM: 384,   testsPerM: 613680  },
  { country: "France",       flag: "🇫🇷", continent: "Europe",         population: 67000000,    cases: 39916587,  deaths: 159887,  recovered: 39200000,  active: 556700,  critical: 648,   casesPerM: 595769, deathsPerM: 2386,  testsPerM: 2850000 },
  { country: "Germany",      flag: "🇩🇪", continent: "Europe",         population: 83000000,    cases: 38249060,  deaths: 170590,  recovered: 37500000,  active: 578470,  critical: 716,   casesPerM: 460832, deathsPerM: 2056,  testsPerM: 1150000 },
  { country: "Brazil",       flag: "🇧🇷", continent: "South America",  population: 213000000,   cases: 37076053,  deaths: 699276,  recovered: 36100000,  active: 276777,  critical: 8318,  casesPerM: 173965, deathsPerM: 3281,  testsPerM: 296000  },
  { country: "South Korea",  flag: "🇰🇷", continent: "Asia",           population: 51700000,    cases: 30616383,  deaths: 34057,   recovered: 30500000,  active: 82326,   critical: 126,   casesPerM: 592195, deathsPerM: 659,   testsPerM: 1400000 },
  { country: "Japan",        flag: "🇯🇵", continent: "Asia",           population: 125700000,   cases: 33803572,  deaths: 74694,   recovered: 33630000,  active: 98878,   critical: 96,    casesPerM: 268920, deathsPerM: 594,   testsPerM: 330000  },
  { country: "Italy",        flag: "🇮🇹", continent: "Europe",         population: 60000000,    cases: 25752545,  deaths: 189965,  recovered: 25400000,  active: 162580,  critical: 252,   casesPerM: 429209, deathsPerM: 3166,  testsPerM: 2200000 },
  { country: "UK",           flag: "🇬🇧", continent: "Europe",         population: 67000000,    cases: 24615063,  deaths: 220019,  recovered: 24300000,  active: 95044,   critical: 156,   casesPerM: 367389, deathsPerM: 3284,  testsPerM: 7410000 },
  { country: "Russia",       flag: "🇷🇺", continent: "Europe",         population: 144000000,   cases: 22940056,  deaths: 399583,  recovered: 22400000,  active: 140473,  critical: 1756,  casesPerM: 159306, deathsPerM: 2775,  testsPerM: 600000  },
  { country: "Turkey",       flag: "🇹🇷", continent: "Asia",           population: 84000000,    cases: 17044947,  deaths: 101198,  recovered: 16900000,  active: 43749,   critical: 791,   casesPerM: 202916, deathsPerM: 1205,  testsPerM: 1560000 },
  { country: "Spain",        flag: "🇪🇸", continent: "Europe",         population: 47000000,    cases: 13897527,  deaths: 121760,  recovered: 13700000,  active: 75767,   critical: 256,   casesPerM: 295693, deathsPerM: 2591,  testsPerM: 1750000 },
  { country: "Vietnam",      flag: "🇻🇳", continent: "Asia",           population: 97000000,    cases: 11527117,  deaths: 43186,   recovered: 11480000,  active: 3931,    critical: 38,    casesPerM: 118836, deathsPerM: 445,   testsPerM: 274000  },
  { country: "Australia",    flag: "🇦🇺", continent: "Oceania",        population: 26000000,    cases: 11500000,  deaths: 21078,   recovered: 11470000,  active: 8922,    critical: 73,    casesPerM: 442308, deathsPerM: 811,   testsPerM: 3870000 },
  { country: "Argentina",    flag: "🇦🇷", continent: "South America",  population: 45000000,    cases: 10044957,  deaths: 130472,  recovered: 9900000,   active: 14485,   critical: 316,   casesPerM: 223221, deathsPerM: 2899,  testsPerM: 539000  },
  { country: "Netherlands",  flag: "🇳🇱", continent: "Europe",         population: 17000000,    cases: 8591321,   deaths: 22947,   recovered: 8540000,   active: 28374,   critical: 57,    casesPerM: 505372, deathsPerM: 1350,  testsPerM: 2170000 },
  { country: "Iran",         flag: "🇮🇷", continent: "Asia",           population: 85000000,    cases: 7598663,   deaths: 146105,  recovered: 7400000,   active: 52558,   critical: 1199,  casesPerM: 89396,  deathsPerM: 1719,  testsPerM: 255000  },
  { country: "Mexico",       flag: "🇲🇽", continent: "North America",  population: 130000000,   cases: 7608845,   deaths: 334788,  recovered: 7200000,   active: 74057,   critical: 3578,  casesPerM: 58530,  deathsPerM: 2575,  testsPerM: 41300   },
  { country: "Indonesia",    flag: "🇮🇩", continent: "Asia",           population: 273000000,   cases: 6800000,   deaths: 161887,  recovered: 6620000,   active: 18113,   critical: 823,   casesPerM: 24908,  deathsPerM: 593,   testsPerM: 39400   },
  { country: "Poland",       flag: "🇵🇱", continent: "Europe",         population: 38000000,    cases: 6453891,   deaths: 119139,  recovered: 6300000,   active: 34752,   critical: 288,   casesPerM: 169839, deathsPerM: 3135,  testsPerM: 440000  },
  { country: "South Africa", flag: "🇿🇦", continent: "Africa",         population: 60000000,    cases: 4072533,   deaths: 102662,  recovered: 3940000,   active: 29871,   critical: 442,   casesPerM: 67876,  deathsPerM: 1711,  testsPerM: 218000  },
  { country: "China",        flag: "🇨🇳", continent: "Asia",           population: 1400000000,  cases: 99239678,  deaths: 121000,  recovered: 98500000,  active: 618678,  critical: 3500,  casesPerM: 70885,  deathsPerM: 86,    testsPerM: 700000  },
  { country: "Pakistan",     flag: "🇵🇰", continent: "Asia",           population: 220000000,   cases: 1577872,   deaths: 30630,   recovered: 1540000,   active: 7242,    critical: 147,   casesPerM: 7172,   deathsPerM: 139,   testsPerM: 48800   },
  { country: "Sri Lanka",    flag: "🇱🇰", continent: "Asia",           population: 22000000,    cases: 671888,    deaths: 16860,   recovered: 652000,    active: 3028,    critical: 48,    casesPerM: 30540,  deathsPerM: 766,   testsPerM: 196000  },
  { country: "Bangladesh",   flag: "🇧🇩", continent: "Asia",           population: 167000000,   cases: 2038628,   deaths: 29445,   recovered: 2000000,   active: 9183,    critical: 56,    casesPerM: 12207,  deathsPerM: 176,   testsPerM: 35500   },
];

export const getRisk = (c) => {
  if (c.deathsPerM > 2000 || c.casesPerM > 300000) return "high";
  if (c.deathsPerM > 500  || c.casesPerM > 80000)  return "medium";
  return "low";
};

export const fmt  = (n) => (n == null ? "N/A" : Number(n).toLocaleString());
export const pct  = (a, b) => (b ? ((a / b) * 100).toFixed(1) + "%" : "N/A");
