import React, { useState, useRef } from "react";
import Header from "./components/Header";
import Hero from "./components/Hero";
import SearchBar from "./components/SearchBar";
import GlobalStats from "./components/GlobalStats";
import CountryResult from "./components/CountryResult";
import NotFound from "./components/NotFound";
import CountryTable from "./components/CountryTable";
import { COUNTRIES } from "./data/covidData";
import "./App.css";

function findCountry(query) {
  const q = query.toLowerCase();
  return COUNTRIES.find(
    (c) =>
      c.country.toLowerCase().includes(q) ||
      q.includes(c.country.toLowerCase())
  );
}

export default function App() {
  const [result, setResult]   = useState(null); // null | { found: true, data } | { found: false, query }
  const resultRef = useRef(null);

  const handleSearch = (query) => {
    const country = findCountry(query);
    setResult(country ? { found: true, data: country } : { found: false, query });
    setTimeout(() => resultRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 50);
  };

  const handleSelect = (name) => {
    const country = findCountry(name);
    if (country) {
      setResult({ found: true, data: country });
      setTimeout(() => resultRef.current?.scrollIntoView({ behavior: "smooth", block: "start" }), 50);
    }
  };

  const handleClear = () => {
    setResult(null);
    window.scrollTo({ top: 0, behavior: "smooth" });
  };

  return (
    <div className="app">
      <Header />
      <Hero />
      <SearchBar onSearch={handleSearch} onClear={handleClear} />
      <GlobalStats />

      {result && (
        <div ref={resultRef}>
          {result.found
            ? <CountryResult country={result.data} />
            : <NotFound query={result.query} />
          }
        </div>
      )}

      <CountryTable onSelect={handleSelect} />

      <footer className="footer">
        Data sourced from{" "}
        <a href="https://www.who.int/emergencies/diseases/novel-coronavirus-2019" target="_blank" rel="noreferrer">
          WHO COVID-19 Dashboard
        </a>{" "}
        &amp; Johns Hopkins University · Final pandemic totals as of May 2023 · Built for health awareness campaigns
      </footer>
    </div>
  );
}
